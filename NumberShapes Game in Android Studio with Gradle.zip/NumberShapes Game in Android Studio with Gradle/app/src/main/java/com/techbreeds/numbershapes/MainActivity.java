package com.techbreeds.numbershapes;

import android.support.annotation.IntegerRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    int QuizLength = 5;
    int[] RandomNumbers;
    int[] GuessedNumbers;
    int GuessedIndex;

    int[] imgarray = new int[11];

    public MainActivity() {
        imgarray[0] = R.drawable.shap0;
        imgarray[1] = R.drawable.shap1;
        imgarray[2] = R.drawable.shap2;
        imgarray[3] = R.drawable.shap3;
        imgarray[4] = R.drawable.shap4;
        imgarray[5] = R.drawable.shap5;
        imgarray[6] = R.drawable.shap6;
        imgarray[7] = R.drawable.shap7;
        imgarray[8] = R.drawable.shap8;
        imgarray[9] = R.drawable.shap9;
        imgarray[10] = R.drawable.shap10;
    }


    protected void initializeQuiz() {

        // Controls Initialization
        Button QuizReset = (Button) findViewById(R.id.QuizReset);
        TextView QuizResults = (TextView) findViewById(R.id.QuizResults);
        QuizReset.setVisibility(View.INVISIBLE);
        QuizResults.setVisibility(View.INVISIBLE);

        // DS Initialization
        GuessedIndex = 0;
        RandomNumbers = new int[QuizLength];
        GuessedNumbers = new int[QuizLength];

        Randomize();

        // Set First Image
        ImageView imgShape = (ImageView) findViewById(R.id.imgShape);
        imgShape.setImageResource(imgarray[RandomNumbers[GuessedIndex]]);
        RotateAnimation rotate = new RotateAnimation(0, 360, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        rotate.setDuration(500);
        rotate.setInterpolator(new LinearInterpolator());
        imgShape.startAnimation(rotate);

    }

    protected void Randomize() {
        Random R = new Random();
        int k = 0, RandomNumber;
        boolean IsRepetitive = false;
        while (k < QuizLength) {
            RandomNumber = R.nextInt(10);

            for (int i = 0; i < QuizLength; i++) {
                IsRepetitive = false;
                if (RandomNumbers[i] == RandomNumber) {
                    IsRepetitive = true;
                    break;
                }
            }
            if (!IsRepetitive) {
                RandomNumbers[k] = RandomNumber;
                k++;
            }
        }

    }

    public void GuessNumber(View view) {

        Button clickedButton = (Button) view;

        Button QuizReset = (Button) findViewById(R.id.QuizReset);
        TextView QuizResults = (TextView) findViewById(R.id.QuizResults);

        ImageView imgShape = (ImageView) findViewById(R.id.imgShape);
        QuizReset.setVisibility(View.INVISIBLE);
        QuizResults.setVisibility(View.INVISIBLE);

        // Quiz Completes
        if (GuessedIndex + 1 == QuizLength) {

            int intNumberGuessed = Integer.parseInt(clickedButton.getText().toString());
            GuessedNumbers[GuessedIndex] = intNumberGuessed;

            AnnounceResult();
        } else if (GuessedIndex < QuizLength) {

            int intNumberGuessed = Integer.parseInt(clickedButton.getText().toString());
            GuessedNumbers[GuessedIndex] = intNumberGuessed;
            GuessedIndex++;

            if (GuessedIndex < RandomNumbers.length) {

                imgShape.animate().alpha(0f).setDuration(1000);
                imgShape.setImageResource(imgarray[RandomNumbers[GuessedIndex]]);
                imgShape.animate().alpha(1f).setDuration(2000);

                RotateAnimation rotate = new RotateAnimation(0, 360, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
                rotate.setDuration(500);
                rotate.setInterpolator(new LinearInterpolator());
                imgShape.startAnimation(rotate);
            }
        }
    }


    protected void AnnounceResult() {


        Button QuizReset = (Button) findViewById(R.id.QuizReset);
        TextView QuizResults = (TextView) findViewById(R.id.QuizResults);

        String RandNumbs = "";
        String YourGuesses = "";

        for (int i = 0; i < QuizLength; i++) {
            RandNumbs = (RandNumbs.length() == 0) ? Integer.toString(RandomNumbers[i]) : RandNumbs + "," + Integer.toString(RandomNumbers[i]);
            YourGuesses = (YourGuesses.length() == 0) ? Integer.toString(GuessedNumbers[i]) : YourGuesses + "," + Integer.toString(GuessedNumbers[i]);
        }

        String ResultAnnouncement = "Quiz Numbers: " + RandNumbs + "\n You Entered : " + YourGuesses;
        ResultAnnouncement = ResultAnnouncement + "\nYour Score: " + countMatches() + " / " + QuizLength;

        QuizResults.setText(ResultAnnouncement);
        QuizResults.setVisibility(View.VISIBLE);
        QuizReset.setVisibility(View.VISIBLE);
    }

    protected int countMatches() {
        int matched = 0;

        for (int i = 0; i < GuessedNumbers.length; i++) {

            if (GuessedNumbers[i] == RandomNumbers[i]) {
                matched++;
            }

        }
        return matched;
    }

    protected void ResetQuiz(View view) {
        initializeQuiz();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initializeQuiz();


    }
}
